const express = require('express');
const mysql = require('mysql');
const path = require('path');
const bodyParser = require("body-parser")
const ejs = require('ejs');

const app = new express();

const db = mysql.createConnection({
	host: "35.239.5.255",
	user: "mak",
	password: "root",
	database: "cmpt470"
});

db.connect((err) => {
	if (err) {
		throw err;
	}
	console.log("mysql connected")
});

app.use(express.static(path.join(__dirname, 'public')))
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.set('views', path.join(__dirname, 'views'))
app.set('view engine','ejs')



app.get('/', (req, res) => {
	let sql = 'SELECT * FROM rectangle ';
	let query =  db.query(sql, (err, results) => {
		if (err) throw err;
		let sql2 = "SELECT COUNT(*) AS count FROM rectangle";
		let query2 = db.query(sql2, (err,count) => {
			if (err) throw err;
		
			res.render("index", {results:results, count:count});
		});
	});
});




app.post('/add', (req,res) => {
	let post = {height: req.body.add_height, 
				width: req.body.add_width, 
				corner: req.body.add_corner,
				borderLen: req.body.add_borderLen,
				borderColor: req.body.add_borderColor,
				boxColor: req.body.add_boxColor};
	let sql = 'INSERT INTO rectangle SET ?';
	let query = db.query(sql, post, (err,result) => {
		if (err) throw err;
		console.log("add succesful");
	})
	res.redirect('/');
});

app.post('/delete', (req,res) => {
	let sql = 'DELETE FROM rectangle WHERE id = '+req.body.ID+'';
	let query = db.query(sql, (err,result) => {
		if (err) throw err;
		console.log("delete succesful");
	});
	res.redirect('/');
});

app.post('/edit', (req,res) => {
	let sql = 'UPDATE rectangle SET height='+req.body.edit_height+', width='+req.body.edit_width+', corner='+req.body.edit_corner+', borderLen='+req.body.edit_borderLen+',borderColor="'+req.body.edit_borderColor+'", boxColor="'+req.body.edit_boxColor+'" WHERE id='+req.body.ID+'';
	let query = db.query(sql, (err,result) => {
		if (err) throw err;
		console.log("edit succesful");
	});
	res.redirect('/');

});





app.listen('8080', () => {
	console.log('server started on port 8080')
})


