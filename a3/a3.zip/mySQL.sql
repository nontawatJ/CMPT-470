/*in gcp shell to log-in to mysql
gcloud sql connect asn3-4-db --user=mak --quiet
*/
/*if gcp shell isnt connec to ur project then 
gcloud config set project nontawatjanpongsri301311427*/




CREATE TABLE rectangle(
	id int NOT NULL AUTO_INCREMENT,
	height int,
	width int,
	corner int,
	borderLen int,
	borderColor varchar(255),
	boxColor varchar(255),
	PRIMARY KEY (id)
);

INSERT INTO rectangle (id,height,width,corner,borderLen,borderColor,boxColor)
VALUES (1,30,90,1,2,"#06cc8a","#ed070f");